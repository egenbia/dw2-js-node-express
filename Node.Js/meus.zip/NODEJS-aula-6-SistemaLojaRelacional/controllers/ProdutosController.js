import express from "express";
import Produto from "../models/Produto.js";
// Importando o model de Cliente
import Cliente from "../models/Cliente.js";
const router = express.Router();

// ROTA produtoS
router.get("/produtos", function (req, res) {
  // Realiza ambas as consultas em paralelo dentro de uma Promessa
  Promise.all([
    Produto.findAll({
      // Fazendo o INNERJOIN com a tabela de Clientes
      include: [
        {
          model: Cliente, // Inclui o modelo Cliente que está relacionado
          required: true, // Garante que somente produtos com clientes sejam retornado
        },
      ],
    }),
    Cliente.findAll(),
  ])
    .then(([produtos, clientes]) => {
      res.render("produtos", {
        produtos: produtos,
        clientes: clientes,
      });
    })
    .catch((err) => {
      console.log(err);
    });
});

// ROTA DE CADASTRO DE produtoS
router.post("/produtos/new", (req, res) => {
  const numero = req.body.numero;
  const valor = req.body.valor;
  const clienteId = req.body.clienteId;
  Produto.create({
    numero: numero,
    valor: valor,
    cliente_id: clienteId,
  })
    .then(() => {
      res.redirect("/produtos");
    })
    .catch((err) => {
      console.log(err);
    });
});

// ROTA DE EXCLUSÃO DE CLIENTES
router.get("/produtos/delete/:id", (req, res) => {
  const id = req.params.id;
  Produto.destroy({
    where: { id: id },
  })
    .then(() => {
      res.redirect("/produtos");
    })
    .catch((err) => {
      console.log(err);
    });
});

export default router;
