import Cliente from "../models/Cliente.js";
import Pedido from "../models/Pedido.js";
import Produto from "../models/Produto.js";

// Definindo as relações entre as entidades (tabelas)
const defineAssociations = () => {
  Cliente.hasMany(Pedido, {foreignKey: "cliente_id"});
  Pedido.belongsTo(Cliente, {foreignKey: "cliente_id"});
};

export default defineAssociations;
