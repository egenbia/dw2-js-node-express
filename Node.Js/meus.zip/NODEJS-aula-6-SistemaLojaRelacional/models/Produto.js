import Sequelize from "sequelize";
import connection from "../config/sequelize-config.js";

const Produto = connection.define("produtos", {
  nome: {  // MUDEI: numero → nome
    type: Sequelize.STRING,
    allowNull: false,
  },
  preco: {  // MUDEI: valor → preco
    type: Sequelize.FLOAT,
    allowNull: false,
  },
  categoria: {  // ADICIONE: categoria
    type: Sequelize.STRING,
    allowNull: false,
  }
});

export default Produto;